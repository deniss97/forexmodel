import sys,re,json,pandas as pd,numpy as np
def load(path):
    s=open(path,encoding='utf-8').read()
    m=re.search(r'<script[^>]*id="lkoh-data"[^>]*>(.*?)</script>',s,re.S)
    return json.loads(m.group(1))
if __name__=="__main__":
    d=load(sys.argv[1]); W=d['weeks']
    rows=[]
    for w in W:
        lv=np.array(w['levels'])
        rows.append((w['start'],len(w['candles']),len(lv),lv[:,1].sum()+lv[:,2].sum(),sum(c[5] for c in w['candles']),w['candles'][0][0],w['candles'][-1][0]))
    df=pd.DataFrame(rows,columns=['start','nc','nl','lv_vol','c_vol','first','last'])
    pd.set_option('display.width',200); pd.set_option('display.max_rows',200)
    print(df.to_string())
    c=pd.DataFrame([x for w in W for x in w['candles']],columns=['t','o','h','l','c','v'])
    c['t']=pd.to_datetime(c['t']); print(len(c)); print(c.t.dt.hour.value_counts().sort_index())
    g=np.log(c.o/c.c.shift()); print(c.assign(g=g)[g.abs()>0.03])
