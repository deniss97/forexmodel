import numpy as np,pandas as pd,warnings; warnings.filterwarnings('ignore')
from scipy import stats
D=pd.read_pickle('features.pkl'); T=pd.read_pickle('targets.pkl'); G=pd.read_pickle('G.pkl')
rng=np.random.default_rng(0); B=1000
def pear(S):  # S: суммы n,x,y,xy,xx,yy
    n,x,y,xy,xx,yy=S.T if S.ndim>1 else S
    return (xy-x*y/n)/np.sqrt((xx-x*x/n)*(yy-y*y/n))
def ic(f,t):
    df=pd.DataFrame({'x':G[f],'y':T[t],'w':D.wk}).dropna()
    if len(df)<500 or df.x.nunique()<4: return None
    x=stats.rankdata(df.x); y=stats.rankdata(df.y)
    M=np.c_[np.ones(len(df)),x,y,x*y,x*x,y*y]; S=pd.DataFrame(M).groupby(df.w.values).sum().values; wk=np.sort(df.w.unique())
    full=pear(S.sum(0)); idx=rng.integers(0,len(S),(B,len(S))); bs=pear(S[idx].sum(1))
    se=bs.std(); a=S[wk<53].sum(0); b=S[wk>=53].sum(0)
    return dict(feat=f,tgt=t,ic=full,se=se,z=full/se,ic_2024=pear(a),ic_2025=pear(b),n=len(df))
R=[]
for t in T.columns:
    for f in G.columns:
        if t.startswith('ret') and f.startswith('abs_'): continue
        x=ic(f,t)
        if x: R.append(x)
R=pd.DataFrame(R); R['p']=2*stats.norm.sf(R.z.abs())
o=R.p.sort_values(); q=(o*len(o)/np.arange(1,len(o)+1))[::-1].cummin()[::-1]; R['q']=q.reindex(R.index)
R['stable']=np.sign(R.ic_2024)==np.sign(R.ic_2025)
R.to_csv('ic_results.csv',index=False,float_format='%.4g')
pd.set_option('display.width',220); pd.set_option('display.max_rows',400)
print('тестов',len(R))
for k in ('ret','vol'):
    s=R[R.tgt.str.startswith(k)]; print(k,'тестов',len(s),' q<0.05:',(s.q<0.05).sum(),' q<0.05 и знак устойчив:',((s.q<0.05)&s.stable).sum(),' ожидалось |z|>2 случайно:',round(0.0455*len(s)),' факт:',(s.z.abs()>2).sum())
for t in T.columns:
    s=R[R.tgt==t]; s=s.reindex(s.z.abs().sort_values(ascending=False).index).head(8)
    print('\n==',t); print(s[['feat','ic','z','ic_2024','ic_2025','q']].round(3).to_string(index=False))
