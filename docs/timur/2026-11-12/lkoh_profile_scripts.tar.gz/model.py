import numpy as np,pandas as pd,warnings; warnings.filterwarnings('ignore')
from scipy import stats
from sklearn.ensemble import HistGradientBoostingRegressor as HGB
D=pd.read_pickle('features.pkl'); G=pd.read_pickle('G.pkl')
lc=np.log(D.c); r=lc.diff(); r2=r**2; a=D.atr
def fwd(h): return np.sqrt(r2[::-1].rolling(h).mean()[::-1].shift(-1))
B=pd.DataFrame({'hour':D.t.dt.hour,'dow':D.t.dt.dayofweek})
for n in (4,8,16,64,256): B[f'rv{n}']=np.log(np.sqrt(r2.rolling(n).mean()).clip(lower=1e-4))
for n in (1,4,16,64): B[f'mom{n}']=(D.c-D.c.shift(n))/a
B['atr_rel']=a/D.c; B['v_rel']=np.log((D.v+1)/(D.v.rolling(80).mean()+1)); B['rng']=(D.h-D.l)/a
# ценовые аналоги уровней, без объёма
for n,p in ((80,'r1'),(320,'r4')):
    m=D.c.rolling(n).mean(); hi=D.h.rolling(n).max(); lo=D.l.rolling(n).min()
    B[p+'_z']=(D.c-m)/a; B[p+'_absz']=B[p+'_z'].abs(); B[p+'_pos']=(D.c-lo)/(hi-lo); B[p+'_w']=(hi-lo)/a
    B[p+'_dhi']=(hi-D.c)/a; B[p+'_dlo']=(D.c-lo)/a
wk=D.groupby('wk').agg(H=('h','max'),L=('l','min'),C=('c','last')).shift(1)
pwk=wk.reindex(D.wk).reset_index(drop=True)
B['pw_dH']=(D.c-pwk.H)/a; B['pw_dL']=(D.c-pwk.L)/a; B['pw_dC']=(D.c-pwk.C)/a; B['pw_w']=(pwk.H-pwk.L)/a
B['pw_dmid']=(D.c-(pwk.H+pwk.L)/2)/a
P=G.copy()
Y={'vol16':np.log(fwd(16).clip(lower=1e-4)),'vol64':np.log(fwd(64).clip(lower=1e-4)),'ret4':lc.shift(-4)-lc,'ret16':lc.shift(-16)-lc,'ret64':lc.shift(-64)-lc}
n=len(D); folds=[(int(n*f),int(n*(f+0.1))) for f in (0.5,0.6,0.7,0.8,0.9)]
def run(X,y,h,seeds=(0,1,2)):
    pred=pd.Series(np.nan,index=D.index); ok=y.notna()
    for s,e in folds:
        tr=np.arange(0,s-h-1); tr=tr[ok.values[tr]]; te=np.arange(s,e)
        p=0
        for sd in seeds:
            m=HGB(max_iter=300,learning_rate=0.03,max_depth=4,min_samples_leaf=80,l2_regularization=1.0,random_state=sd,max_features=0.5)
            m.fit(X.iloc[tr],y.iloc[tr]); p=p+m.predict(X.iloc[te])/len(seeds)
        pred.iloc[te]=p
    return pred
out=[]; preds={}
sets={'база':B,'база+профиль':pd.concat([B,P],axis=1),'только профиль':P}
for t,y in Y.items():
    h=int(t[3:])
    for nm,X in sets.items():
        p=run(X,y,h); preds[(t,nm)]=p; m=p.notna()&y.notna()
        row=dict(tgt=t,set=nm,ic=stats.spearmanr(p[m],y[m])[0],r2=1-((y[m]-p[m])**2).sum()/((y[m]-y[m].mean())**2).sum())
        fo=[stats.spearmanr(p.iloc[s:e][m.iloc[s:e]],y.iloc[s:e][m.iloc[s:e]])[0] for s,e in folds]; row['folds']=' '.join(f'{x:+.2f}' for x in fo)
        if t.startswith('ret'):
            pos=np.sign(p[m]); row['hit']=(np.sign(y[m])==pos).mean()
        out.append(row); print(row,flush=True)
pd.DataFrame(out).to_csv('model_results.csv',index=False,float_format='%.4g'); pd.to_pickle((preds,Y,folds),'preds.pkl')
# частная связь: волатильность после вычета базы
print('\nЧастный IC топ-фичей с остатком vol16 после базовой модели (вне выборки):')
res=(Y['vol16']-preds[('vol16','база')])
for f in ['abs_r1_va_out','abs_r1_d_vah','abs_r1_d_poc','abs_r1_va_rel','r1_dens_dn','r4_d_lvn','r4_d_hvn','abs_pw_d_vah','m4_delta','pw_va_w','r1_dens_here','r4_dens_here','m4_dens_here']:
    m=res.notna()&P[f].notna(); print(f'{f:16s} {stats.spearmanr(P[f][m],res[m])[0]:+.3f}  n={m.sum()}')
