import numpy as np,pandas as pd,warnings; warnings.filterwarnings('ignore')
from scipy import stats
exec(open('/home/claude/work/model.py').read().split("out=[]; preds={}")[0])
T=pd.read_pickle('targets.pkl'); cut=int(n*0.5)-70
def select(t,k=8,vol=True):
    rows=[]
    for f in P.columns:
        if (not vol) and f.startswith('abs_'): continue
        x=P[f].iloc[:cut]; y=T[t].iloc[:cut]; m=x.notna()&y.notna()
        if m.sum()<1500: continue
        h=cut//2; i1=stats.spearmanr(x[:h][m[:h]],y[:h][m[:h]])[0]; i2=stats.spearmanr(x[h:][m[h:]],y[h:][m[h:]])[0]
        if np.sign(i1)==np.sign(i2): rows.append((f,min(abs(i1),abs(i2))))
    rows.sort(key=lambda z:-z[1]); sel=[]
    for f,_ in rows:   # без почти-дубликатов
        if all(abs(P[f].iloc[:cut].corr(P[g].iloc[:cut],method='spearman'))<0.8 for g in sel): sel.append(f)
        if len(sel)>=k: break
    return sel
for t,tt in (('vol16','vol16'),('vol64','vol64'),('ret4','ret4'),('ret16','ret16'),('ret64','ret64')):
    sel=select(tt,vol=t.startswith('vol')); y=Y[t]; h=int(t[3:])
    for nm,X in (('база',B),('база+отобранные',pd.concat([B,P[sel]],axis=1))):
        p=run(X,y,h,seeds=(0,1,2,3,4)); m=p.notna()&y.notna()
        fo=[stats.spearmanr(p.iloc[s:e][m.iloc[s:e]],y.iloc[s:e][m.iloc[s:e]])[0] for s,e in folds]
        print(t,nm,f'ic={stats.spearmanr(p[m],y[m])[0]:+.3f}',f'r2={1-((y[m]-p[m])**2).sum()/((y[m]-y[m].mean())**2).sum():+.3f}','folds',' '.join(f'{x:+.2f}' for x in fo))
    print('   отобраны:',sel)
