import sys,numpy as np,pandas as pd
sys.path.insert(0,"/home/claude/work"); from load import load
STEP=5
d=load(sys.argv[1]); W=d['weeks'][:119]          # без одиночного дня 08.11.2026
c=pd.DataFrame([x+[k] for k,w in enumerate(W) for x in w['candles']],columns=['t','o','h','l','c','v','wk'])
c['t']=pd.to_datetime(c['t'])
# --- дивидендные гэпы: аддитивная корректировка прошлого ---
EX=['2024-05-07','2024-12-17','2025-06-03','2026-01-10']
off=np.zeros(len(c)); exw=set(); wk_off=np.zeros(len(W))
for e in EX:
    i=c.index[c.t>=e][0]; gap=c.o[i]-c.c[i-1]; print('ex',e,c.t[i],round(gap,1))
    off[:i]+=gap; w=c.wk[i]; exw.add(w); wk_off[:w]+=gap     # недели до экс-недели сдвигаем; сама экс-неделя — смешанная
for k in 'ohlc': c[k]=c[k]+off
tr=np.maximum(c.h,c.c.shift())-np.minimum(c.l,c.c.shift())
c['atr']=tr.ewm(span=60,min_periods=30).mean()
# --- профили ---
def analyse(p,vol,buy,sell):
    tot=vol.sum(); pi=int(vol.argmax()); lo=hi=pi; acc=vol[pi]; n=len(vol)
    while acc<0.7*tot and (lo>0 or hi<n-1):
        dn=vol[lo-1] if lo>0 else -1; up=vol[hi+1] if hi<n-1 else -1
        if dn>=up: lo-=1; acc+=vol[lo]
        else: hi+=1; acc+=vol[hi]
    sep=max(3*STEP,0.004*p[pi]); peaks=[k for k in range(n) if vol[k]>0 and vol[k]>=(vol[k-1] if k>0 else -1) and vol[k]>=(vol[k+1] if k<n-1 else -1)]
    peaks.sort(key=lambda k:-vol[k]); hv=[]
    for k in peaks:
        if vol[k]<0.25*vol[pi]: break
        if all(abs(p[j]-p[k])>=sep for j in hv): hv.append(k)
        if len(hv)>=5: break
    if pi not in hv: hv.insert(0,pi)
    hs=sorted(hv); lv=[]
    for a,b in zip(hs[:-1],hs[1:]):
        if b-a>1:
            mk=a+1+int(vol[a+1:b].argmin())
            if vol[mk]<=0.6*min(vol[a],vol[b]): lv.append(mk)
    mid=p+STEP/2; m=(mid*vol).sum()/tot; sd=np.sqrt(((mid-m)**2*vol).sum()/tot)
    q=vol[vol>0]/tot
    return dict(p=p,mid=mid,vol=vol,buy=buy,sell=sell,tot=tot,poc=mid[pi],val=p[lo],vah=p[hi]+STEP,hvn=mid[hs],lvn=mid[lv] if lv else np.array([]),
        skew=((mid-m)**3*vol).sum()/tot/sd**3, ent=-(q*np.log(q)).sum()/np.log(len(vol)), nhvn=len(hs),
        pocpos=(mid[pi]-p[0])/(p[-1]+STEP-p[0]), delta=(buy.sum()-sell.sum())/tot,
        va_delta=(buy[lo:hi+1].sum()-sell[lo:hi+1].sum())/vol[lo:hi+1].sum())
def build(levels):   # levels: массив [цена, buy, sell] в скорректированных координатах
    b=np.floor(levels[:,0]/STEP).astype(int); lo,hi=b.min(),b.max(); n=hi-lo+1
    buy=np.bincount(b-lo,levels[:,1],n); sell=np.bincount(b-lo,levels[:,2],n)
    return analyse((lo+np.arange(n))*STEP*1.0,buy+sell,buy,sell)
LV=[np.array(w['levels'],float)+[wk_off[k],0,0] for k,w in enumerate(W)]
PW={k:build(LV[k]) for k in range(len(W)) if k not in exw}
def comp(k,n=4):
    ks=[j for j in range(k-n+1,k+1) if j>=0 and j not in exw]
    return build(np.vstack([LV[j] for j in ks])) if len(ks)>=3 else None
M4={k:comp(k) for k in range(len(W))}
def pf(P,x,a,pre):
    f={}
    if P is None: return f
    f[pre+'d_poc']=(x-P['poc'])/a
    f[pre+'d_vah']=(x-P['vah'])/a; f[pre+'d_val']=(x-P['val'])/a
    f[pre+'va_pos']=float(np.sign(x-P['vah'])) if x>P['vah'] else (-1.0 if x<P['val'] else 0.0)
    f[pre+'va_out']=max(x-P['vah'],0)/a-max(P['val']-x,0)/a
    f[pre+'va_rel']=(x-(P['vah']+P['val'])/2)/((P['vah']-P['val'])/2)
    f[pre+'va_w']=(P['vah']-P['val'])/a
    mid,vol=P['mid'],P['vol']; mean=vol.mean()
    near=np.abs(mid-x)<=1.5*STEP
    f[pre+'dens_here']=vol[near].mean()/mean if near.any() else 0.0
    f[pre+'delta_here']=(P['buy'][near].sum()-P['sell'][near].sum())/vol[near].sum() if near.any() and vol[near].sum()>0 else np.nan
    f[pre+'vol_above']=vol[mid>x].sum()/P['tot']
    R=2*a; up=(mid>x)&(mid<=x+R); dn=(mid<x)&(mid>=x-R)
    vu,vd=vol[up].sum()/P['tot'],vol[dn].sum()/P['tot']
    f[pre+'dens_up']=vu; f[pre+'dens_dn']=vd; f[pre+'dens_ud']=vu-vd
    f[pre+'delta_up']=(P['buy'][up].sum()-P['sell'][up].sum())/vol[up].sum() if vol[up].sum()>0 else np.nan
    f[pre+'delta_dn']=(P['buy'][dn].sum()-P['sell'][dn].sum())/vol[dn].sum() if vol[dn].sum()>0 else np.nan
    for nm,arr in (('hvn',P['hvn']),('lvn',P['lvn'])):
        if len(arr):
            dd=(arr-x)/a; f[pre+'d_'+nm]=float(np.abs(dd).min())
            upn=dd[dd>0]; dnn=dd[dd<=0]
            if nm=='hvn': f[pre+'hvn_asym']=(min(upn.min(),20) if len(upn) else 20)-(min(-dnn.max(),20) if len(dnn) else 20)  # >0: ближайший узел снизу ближе
    f[pre+'skew']=P['skew']; f[pre+'ent']=P['ent']; f[pre+'nhvn']=P['nhvn']; f[pre+'pocpos']=P['pocpos']
    f[pre+'delta']=P['delta']; f[pre+'va_delta']=P['va_delta']
    return f
# «непротестированные» POC
ws=c.groupby('wk').t.agg(['min','max'])
rows=[]; naked={}   # wk -> poc
H,L,C,A,WK=c.h.values,c.l.values,c.c.values,c.atr.values,c.wk.values
prev=-1
for i in range(len(c)):
    w=WK[i]
    if w!=prev:
        if prev in PW: naked[prev]=PW[prev]['poc']
        for k in [k for k in naked if k<w-26]: naked.pop(k)
        prev=w
    for k in [k for k,v in naked.items() if L[i]<=v<=H[i]]: naked.pop(k)
    a=A[i]; x=C[i]; f={}
    if not np.isnan(a) and a>0:
        f.update(pf(PW.get(w-1),x,a,'pw_')); f.update(pf(M4.get(w-1),x,a,'m4_'))
        if (w-1) in PW and (w-2) in PW:
            p1,p2=PW[w-1],PW[w-2]
            f['dyn_poc_shift']=(p1['poc']-p2['poc'])/a
            ov=max(0,min(p1['vah'],p2['vah'])-max(p1['val'],p2['val']))
            f['dyn_va_overlap']=ov/min(p1['vah']-p1['val'],p2['vah']-p2['val'])
        if naked:
            dd=np.array(list(naked.values()))-x; j=np.abs(dd).argmin()
            f['npoc_d']=dd[j]/a; f['npoc_n']=len(naked)
            f['npoc_up']=(dd>0).sum()-(dd<0).sum()
    rows.append(f)
F=pd.DataFrame(rows)
# --- скользящий профиль по часовым свечам (объём бара размазан по high–low; дельты нет) ---
O,V=c.o.values,c.v.values
lob=np.floor(L/STEP).astype(int); hib=np.floor(H/STEP).astype(int)
def roll(Nw,pre):
    out=[]
    for i in range(len(c)):
        if i<Nw or np.isnan(A[i]): out.append({}); continue
        s=slice(i-Nw+1,i+1); b0=lob[s].min(); n=hib[s].max()-b0+1
        vol=np.zeros(n+1)
        for l_,h_,v_ in zip(lob[s]-b0,hib[s]-b0,V[s]):
            vol[l_:h_+1]+=v_/(h_-l_+1)
        vol=vol[:n]; P=analyse((b0+np.arange(n))*STEP*1.0,vol,vol*0,vol*0)
        f=pf(P,C[i],A[i],pre); out.append({k:v for k,v in f.items() if 'delta' not in k})
    return pd.DataFrame(out)
F=pd.concat([F,roll(80,'r1_'),roll(320,'r4_')],axis=1)
# события относительно зоны стоимости прошлой недели
pos=F['pw_va_pos']; same=pd.Series(WK).eq(pd.Series(WK).shift(8))
F['ev_reentry']=((pos==0)&(pos.shift(8)!=0)&pos.shift(8).notna()&same).astype(float)*np.sign(-pos.shift(8).fillna(0))  # +1: вернулись снизу
F['ev_break']=((pos!=0)&(pos.shift(8)==0)&same).astype(float)*pos
F.loc[pos.isna(),['ev_reentry','ev_break']]=np.nan
out=pd.concat([c,F],axis=1); out.to_pickle('features.pkl'); out.to_csv('lkoh_volume_profile_features.csv',index=False,float_format='%.5g'); print(out.shape); print(F.notna().mean().round(2).to_string())
